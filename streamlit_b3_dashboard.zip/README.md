
# Dashboard B3 - Comparação de Estratégias Quantitativas

Este aplicativo permite comparar o desempenho de diferentes estratégias quantitativas aplicadas a ações do Ibovespa, com visualização da curva de capital e exportação dos resultados.

## Como usar no Streamlit Cloud

1. Crie uma conta ou entre em [https://streamlit.io/cloud](https://streamlit.io/cloud)
2. Crie um novo app e conecte este repositório ou envie os arquivos do ZIP
3. O nome do arquivo principal deve ser `streamlit_app.py`
4. O arquivo `requirements.txt` deve estar presente com as dependências
